Sample template for [Jekyll](https://github.com/mojombo/jekyll)
============================

This gives a very basic template for generating publication webpage from a [BibTeX](http://www.bibtex.org) file using jekyll-scholar and jekyll-scholar-extras.

Make sure you move this out of the jekyll-scholar-extras directory to not result in some odd dependency errors.
