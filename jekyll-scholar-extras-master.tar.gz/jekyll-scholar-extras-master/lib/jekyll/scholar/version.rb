module Jekyll
  class ScholarExtras
    VERSION = '0.1.5'.freeze
  end
end
