#require 'jekyll/scholar'
require 'jekyll/scholar/extras'
